// Importok
import './App.css'
import Navbar from './Navbar'
import Card from './Card'

// Fgv a komponenshez
export default function App() {
  // JS
  let nev = "Zsolti";

  return (
    // HTML
    <>
      <Navbar />
      <div className="justify-content-center mb-5">
        <h1 className='piros'>Hello {nev}!</h1>
        <button className="btn btn-primary w-25 border-4 border-dark">Bádön</button>
      </div>
      <div className="d-flex gap-4 justify-content-center">
        <Card />
        <Card />
        <Card />
      </div>
    </>
  )
}
