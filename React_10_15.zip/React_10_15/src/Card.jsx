import './Card.css'
import kep from './assets/18917.jpg'

export default function Navbar() {

  return (
    <>
      <div className="card w-25 border-4 border-dark">
        <img className="img-fluid border-bottom border-dark border-4 card-img-top" src={kep} alt="Kártya kép"/>
        <div className="card-body">
          <h5 className="card-title">Astra</h5>
          <p className="card-text">Jimmy az Astrán</p>
          <a href="https://www.hasznaltauto.hu/szemelyauto/opel/astra/astra_g" target="_blank" rel="noopener noreferrer" className="btn btn-primary border-3 border-dark">Gomb</a>
        </div>
      </div>
    </>
  )
}
