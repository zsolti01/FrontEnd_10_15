import './Navbar.css'

export default function Navbar() {

  return (
    <>
      <nav class="navbar">
        <div class="logo">MyWebsite</div>
        
            <ul class="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#cart">Cart</a></li>
                <li><a href="#profile">Profile</a></li>
            </ul>
        </nav>
    </>
  )
}
